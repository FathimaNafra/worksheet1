import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegistrationForm extends JFrame {
    private JTextField nameField, mobileField, dobDayField, dobYearField;
    private JComboBox<String> dobMonthComboBox;
    private JRadioButton maleRadioButton, femaleRadioButton;
    private ButtonGroup genderGroup;
    private JTextArea addressArea, outputArea;
    private JCheckBox termsCheckBox;
    private JButton submitButton, resetButton;

    public RegistrationForm() {
        setTitle("Registration Form");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Creating the form panel
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));

        // Adding form fields
        formPanel.add(new JLabel("Name: "));
        nameField = new JTextField(20);
        formPanel.add(nameField);

        formPanel.add(new JLabel("Mobile: "));
        mobileField = new JTextField(20);
        formPanel.add(mobileField);

        formPanel.add(new JLabel("Gender: "));
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        maleRadioButton = new JRadioButton("Male");
        femaleRadioButton = new JRadioButton("Female");
        genderGroup = new ButtonGroup();
        genderGroup.add(maleRadioButton);
        genderGroup.add(femaleRadioButton);
        genderPanel.add(maleRadioButton);
        genderPanel.add(femaleRadioButton);
        formPanel.add(genderPanel);

        formPanel.add(new JLabel("DOB: "));
        JPanel dobPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        dobDayField = new JTextField(2);
        dobMonthComboBox = new JComboBox<>(new String[]{
                "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"});
        dobYearField = new JTextField(4);
        dobPanel.add(dobDayField);
        dobPanel.add(dobMonthComboBox);
        dobPanel.add(dobYearField);
        formPanel.add(dobPanel);

        formPanel.add(new JLabel("Address: "));
        addressArea = new JTextArea(3, 20);
        formPanel.add(new JScrollPane(addressArea));

        termsCheckBox = new JCheckBox("Accept Terms And Conditions.");
        formPanel.add(termsCheckBox);

        // Adding output display area
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane outputScrollPane = new JScrollPane(outputArea);

        // Adding buttons
        JPanel buttonPanel = new JPanel();
        submitButton = new JButton("Submit");
        resetButton = new JButton("Reset");
        buttonPanel.add(submitButton);
        buttonPanel.add(resetButton);

        // Adding action listeners
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleSubmit();
            }
        });

        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearForm();
            }
        });

        // Adding components to the frame
        add(new JLabel("Registration Form", JLabel.CENTER), BorderLayout.NORTH);
        add(formPanel, BorderLayout.WEST);
        add(outputScrollPane, BorderLayout.EAST);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void handleSubmit() {
        if (!termsCheckBox.isSelected()) {
            JOptionPane.showMessageDialog(this, "Please accept the Terms and Conditions.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String name = nameField.getText().trim();
        String mobile = mobileField.getText().trim();
        String gender = maleRadioButton.isSelected() ? "Male" : femaleRadioButton.isSelected() ? "Female" : "Not Selected";
        String dob = dobDayField.getText() + "/" + dobMonthComboBox.getSelectedItem() + "/" + dobYearField.getText();
        String address = addressArea.getText().trim();

        if (name.isEmpty() || mobile.isEmpty() || address.isEmpty() || dobDayField.getText().isEmpty() || dobYearField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        outputArea.setText("Name: " + name + "\n" +
                "Mobile: " + mobile + "\n" +
                "Gender: " + gender + "\n" +
                "DOB: " + dob + "\n" +
                "Address: " + address + "\n" +
                "Registration Successfully..");
    }

    private void clearForm() {
        nameField.setText("");
        mobileField.setText("");
        genderGroup.clearSelection();
        dobDayField.setText("");
        dobMonthComboBox.setSelectedIndex(0);
        dobYearField.setText("");
        addressArea.setText("");
        termsCheckBox.setSelected(false);
        outputArea.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(RegistrationForm::new);
    }
}

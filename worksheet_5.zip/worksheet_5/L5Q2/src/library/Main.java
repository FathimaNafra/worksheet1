package library;
import library.utils.BookUtils;
import  library.books.FictionBook;

public class Main {
    public static void main(String[] args) {
        FictionBook book = new FictionBook("Harry Potter", "J.K. Rowling", "Fantasy");
        book.displayInfo();
        BookUtils.printBookDetails(book);

    }
}

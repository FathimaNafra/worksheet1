
public class BankManagementSystem {
    public static void main(String[] args) {

        BankAccount account = new BankAccount();
        account.deposit(500);
        account.withdraw(200);
        account.withdraw(400);
        System.out.println("Current Balance: $" + account.getBalance());
    }
}

public class L5Q1 {

    // Declare final constants
    public static final double PI = 3.14159;
    public static final int SPEED_OF_LIGHT = 299792458;
    public final double GRAVITY;

    // Constructor to initialize GRAVITY
    public L5Q1(double gravity) {
        this.GRAVITY = gravity;
    }

    // Main method to test the class
    public static void main(String[] args) {
        // Create an instance with a specific gravity value
        L5Q1 constants = new L5Q1(9.81);

        // Print values
        System.out.println("PI: " + L5Q1.PI);
        System.out.println("Speed of Light: " + L5Q1.SPEED_OF_LIGHT + " ms^-1");
        System.out.println("Gravity: " + constants.GRAVITY + " ms^-2");
    }
}



public class AreaCalculator {


    public static double calculateRectangleArea(double length, double width) {
        double area = length * width;  // Local variable
        return area;
    }


    public static double calculateSquareArea(double sideLength) {
        double area = sideLength * sideLength;  // Local variable
        return area;
    }


    public static void main(String[] args) {
        // Variables declared in the main method (local scope)
        double rectangleLength = 5;
        double rectangleWidth = 8;
        double squareSideLength = 4;


        double rectangleArea = calculateRectangleArea(rectangleLength, rectangleWidth);
        System.out.println("Area of Rectangle: " + rectangleArea);

        double squareArea = calculateSquareArea(squareSideLength);
        System.out.println("Area of Square: " + squareArea);
    }
}
